# import logging
# from logging import Logger

# def setup_logger(log_file: str = "bot.log") -> Logger:
#     """Configure application logger with file and stream handlers."""
#     logger = logging.getLogger("binance_bot")
#     logger.setLevel(logging.INFO)

#     fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s", "%Y-%m-%d %H:%M:%S")

#     fh = logging.FileHandler(log_file)
#     fh.setFormatter(fmt)
#     sh = logging.StreamHandler()
#     sh.setFormatter(fmt)

#     logger.handlers = []
#     logger.addHandler(fh)
#     logger.addHandler(sh)

#     return logger
